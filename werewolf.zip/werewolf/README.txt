Xack's quick werewolf fix

- This changes the modern model werewolves to be the classic ones
- If you see new modern werewolves slipping through, you can rename wwf.eqg to wwf.eqg.old or any other name
- Changes your globalfroglok_chr.s3d. It should not affect frogloks but just piggy backs it
- Extract this zip to your game folder, it will likely ask you to overwrite the s3d. You may want to consider backing these up.