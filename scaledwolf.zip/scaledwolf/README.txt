Scaled Wolf Fix

- This replaces scaled wolves to classic variants on THJ (or other servers)
- Changes your grass.s3d
- Extract this zip to your game folder, it will likely ask you to overwrite files. You may want to consider backing these up.