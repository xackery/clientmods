Copy these files into your EQ sounds folder to reduce volume of inventory sounds like boxes and bags.
