Xack's quick Spectre fix

- This changes the new model spectres to be the classic ones.
- Changes your global6_chr2.s3d
- Extract this zip to your game folder, it will likely NOT ask you to overwrite files. If it does, you may want to consider backing these up.